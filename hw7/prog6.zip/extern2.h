// Remember: include simply inserts all lines into file during preprocessing
#include <stdio.h>
#include <math.h>

//extern int i;
int i;   // extern by default
extern void hypcos(void);
extern void hypsin(void);
