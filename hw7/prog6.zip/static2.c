#include <stdio.h>
#include <math.h>

void hypcos(void)
{
    float x, y;
    static int i; // static and initialized to zero
    int j;        // not static and not initialized

    x = exp(++i);
    y = exp(-i);

    printf("hypcos[%2d] = %f\n", i, (x + y)/2);
    printf("j = %d\n", ++j);
}

int main(void)
{
    int n;

    for (n=0; n<10; n++) {
        hypcos();
    }

    return 0;
}
