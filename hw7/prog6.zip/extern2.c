// global variables and prototypes found in header file
#include "extern2.h"

// prototype if use static function junk not found and linder error
//static void junk(void);

//int i;   // found in header file
//
void junk(void)
{
    printf("nothing\n");
}


// found without extern since it is assumed
void hypcos(void)
{
    float x, y;

    x = exp(i);
    y = exp(-i);

    printf("hypcos[%2d] = %f", i, (x + y)/2);
}

void hypsin(void)
{
    float x, y;

    x = exp(i);
    y = exp(-i);
    printf("   \thypsin[%2d] = %f\n", i, (x - y)/2);
}

