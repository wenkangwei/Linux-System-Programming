/*************************************************
 *  Copyright (C) 1999-2006 by  ZiLOG, Inc.
 *  All Rights Reserved
 *************************************************/

#ifndef EZ8_H
#define EZ8_H

#if defined(_Z8ENCORE_F642X) || defined(_Z8ENCORE_64K_SERIES)
#define _Z8F642
#endif

#if defined(_Z8ENCORE_F640X) || defined(_Z8ENCORE_640_FAMILY)
#define _Z8F640
#endif

#if defined(_Z8ENCORE_F08X) || defined(_Z8ENCORE_8K_SERIES)
#define _Z8F08
#endif

#if defined(_Z8ENCORE_F04XA) || defined(_Z8ENCORE_XP_4K_SERIES)
#define _Z8F04A
#endif

#if defined(_Z8ENCORE_4K_SERIES)
#define _Z8F04
#endif

#if defined(_Z8ENCORE_4K_8PIN_SERIES)
#define _Z8F04_8PIN
#define _Z8F04
#endif

#if defined(_Z8ENCORE_XP_4K_8PIN_SERIES)
#define _Z8F04A_8PIN
#define _Z8F04A
#endif

#if defined(_Z8ENCORE_XP_F08XA_SERIES)
#define _Z8F04A
#define _Z8F08A
#endif

#if defined(_Z8ENCORE_XP_F0830_SERIES) || defined(_Z8ENCORE_XP_F083A_SERIES)
#define _Z8F04A
#define _Z8F0830A
#endif

#if defined(_Z8ENCORE_XP_F0830_SERIES)
#define _Z8F0830S
#endif

#if defined(_Z8ENCORE_XP_F08XA_8PIN_SERIES)
#define _Z8F04A
#define _Z8F08A
#define _Z8F04A_8PIN
#endif

#if defined(_Z8ENCORE_F0823_SERIES)
#define _Z8F04
#endif

#if defined(_Z8ENCORE_F0823_8PIN_SERIES)
#define _Z8F04
#define _Z8F0823_8PIN
#endif

#if defined(_Z8ENCORE_Z8FMC16100_SERIES)
#define _Z8FMC16
#endif

#if defined(_Z8ENCORE_XP_F1680_SERIES)
#define _Z8F1680
#endif

#if defined(_Z8ENCORE_XP_F1680_SERIES_24K) || defined(_Z8ENCORE_XP_F1680_SERIES_16K)
#define _Z8F1680
#endif

#if defined(_Z8ENCORE_XP_F1680_SERIES_8K) || defined(_Z8ENCORE_XP_F1680_SERIES_4K)
#define _Z8F1680
#endif

#if defined(_Z8F642) || defined(_Z8F640) || defined(_Z8F08) || defined(_Z8F04)
#define ENCORE_VECTORS
#endif

#if defined(_Z8F04A)
#define ENCORE_XP_VECTORS
#endif

#if defined(_Z8FMC16)
#define ENCORE_MC_VECTORS
#endif

#if defined(_Z8F1680)
#define ENCORE_XP16K_VECTORS
#endif

#define EZ8_IRQ3
#define EZ8_TIMER2
#define EZ8_UART0

#if defined(_Z8F640) || defined(_Z8F642)
#define EZ8_SPI
#define EZ8_ADC
#define EZ8_TIMER3
#define EZ8_PORT4
#define EZ8_I2C
#endif

#if defined(_Z8F640) || defined(_Z8F642) || defined(__ZSLBUILD)
#define EZ8_UART1
#define EZ8_DMA
#endif

#if defined(_Z8F08)
#define EZ8_I2C
#endif

#if defined(_Z8F04A)  && !defined(_Z8F08A)
#define EZ8_NVDS
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(__ZSLBUILD)
#define EZ8_PORT4
#endif

#if defined(_Z8F04A_8PIN) || defined(_Z8F0823_8PIN) || defined(_Z8F04_8PIN)
#define EZ8_PORT1
#undef EZ8_IRQ3
#endif

#if defined(_Z8F0830A)
#undef EZ8_UART0
#endif

#if defined(_Z8FMC16)
#define EZ8_ADC_NEW
#define EZ8_PWM
#undef EZ8_TIMER2
#undef EZ8_IRQ3
#endif

#if defined(_Z8F1680)
#define EZ8_TIMER3
#define EZ8_I2C
#define EZ8_PORT4
#define EZ8_NVDS
#endif

#if defined(_Z8F2480XH) || defined(_Z8F2480XJ) || defined(_Z8F2480XM) || defined(_Z8F2480XN)
#undef EZ8_NVDS
#endif

#if defined(_Z8F2481XH) || defined(_Z8F2481XJ) || defined(_Z8F2481XM) || defined(_Z8F2481XN)
#undef EZ8_NVDS
#endif

#if defined(_Z8F2480XH) || defined(_Z8F1680XH) || defined(_Z8F0880XH) || defined(_Z8F0480XH)
#define EZ8_ADC_NEW
#endif

#if defined(_Z8F2480XJ) || defined(_Z8F1680XJ) || defined(_Z8F0880XJ) || defined(_Z8F0480XJ)
#define EZ8_ESPI
#define EZ8_ADC_NEW
#endif

#if defined(_Z8F2480XM) || defined(_Z8F1680XM) || defined(_Z8F0880XM) || defined(_Z8F0480XM)
#define EZ8_ESPI
#define EZ8_UART1
#define EZ8_CMP1
#define EZ8_ADC_NEW
#define EZ8_PORT5 
#endif

#if defined(_Z8F2480XN) || defined(_Z8F1680XN) || defined(_Z8F0880XN) || defined(_Z8F0480XN)
#define EZ8_ESPI
#define EZ8_UART1
#define EZ8_CMP1
#define EZ8_ADC_NEW
#define EZ8_PORT5
#define EZ8_MCT
#endif

#if defined(_Z8F2481XJ) || defined(_Z8F1681XJ) || defined(_Z8F0881XJ) || defined(_Z8F0481XJ)
#define EZ8_ESPI
#endif

#if defined(_Z8F2481XM) || defined(_Z8F1681XM) || defined(_Z8F0881XM) || defined(_Z8F0481XM)
#define EZ8_ESPI
#define EZ8_UART1
#define EZ8_CMP1
#define EZ8_PORT5 
#endif

#if defined(_Z8F2481XN) || defined(_Z8F1681XN) || defined(_Z8F0881XN) || defined(_Z8F0481XN)
#define EZ8_ESPI
#define EZ8_UART1
#define EZ8_CMP1
#define EZ8_PORT5 
#define EZ8_MCT
#endif

#if defined(_Z8FMC16100) || defined(_Z8FMC08100) || defined(_Z8FMC04100)
#define EZ8_I2C
#define EZ8_SPI
#endif

#if  defined(_Z8F6423) || defined(_Z8F6422) || defined(_Z8F4823) || defined(_Z8F4822)
#define EZ8_TIMER4
#endif

#if  defined(_Z8F3222) || defined(_Z8F2422) || defined(_Z8F1622)    
#define EZ8_TIMER4
#endif

#if  defined(_Z8F6423) || defined(_Z8F6422) || defined(_Z8F4823) || defined(_Z8F4822) || defined(__ZSLBUILD)
#define EZ8_PORT8
#endif

#if  defined(_Z8F3222) || defined(_Z8F2422) || defined(_Z8F1622)
#define EZ8_PORT8
#endif

#if  defined(_Z8F6403) || defined(_Z8F6402) || defined(_Z8F4803) || defined(_Z8F4802)
#define EZ8_TIMER4
#endif

#if  defined(_Z8F3202) || defined(_Z8F2402) || defined(_Z8F1602)    
#define EZ8_TIMER4
#endif

#if  defined(_Z8F6403) || defined(_Z8F6402) || defined(_Z8F4803) || defined(_Z8F4802)
#define EZ8_PORT8
#endif

#if  defined(_Z8F3202) || defined(_Z8F2402) || defined(_Z8F1602)
#define EZ8_PORT8
#endif


#if defined(_Z8F0822) || defined(_Z8F0812) || defined(_Z8F0422) || defined(_Z8F0412)
#define EZ8_SPI 
#endif

#if defined(_Z8F0822) || defined(_Z8F0821) || defined(_Z8F0422) || defined(_Z8F0421)
#define EZ8_ADC 
#endif

#if defined(_Z8F042A) || defined(_Z8F022A) || defined(_Z8F012A) || defined(_Z8F082A) 
#define EZ8_ADC
#endif

#if defined(_Z8F042AXB) || defined(_Z8F022AXB) || defined(_Z8F012AXB) || defined(_Z8F082AXB)
#define EZ8_ADC
#endif

#if defined(_Z8F0423XH) || defined(_Z8F0223XH) || defined(_Z8F0123XH)
#define EZ8_ADC
#endif

#if defined(_Z8F0423XJ) || defined(_Z8F0223XJ) || defined(_Z8F0123XJ) 
#define EZ8_ADC
#endif

#if defined(_Z8F0423) || defined(_Z8F0223) || defined(_Z8F0123)
#define EZ8_ADC
#endif

#if defined(_Z8F0423XB) || defined(_Z8F0223XB) || defined(_Z8F0123XB)
#define EZ8_ADC
#endif

#if defined(_Z8F0823) || defined(_Z8F0823XB)
#define EZ8_ADC
#endif

#if defined(_Z8F1232) || defined(_Z8F0832) || defined(_Z8F0830) || defined(_Z8F0430) || defined(_Z8F0432)
#define EZ8_ADC_NEW
#endif

#if defined(_Z8F0232) || defined(_Z8F0230) || defined(_Z8F0132) || defined(_Z8F0130)
#define EZ8_ADC_NEW
#endif

#if defined(_Z8F1232) || defined(_Z8F1233) || defined(_Z8F0832) || defined(_Z8F0833) || defined(_Z8F0432)
#undef EZ8_NVDS
#endif

#if defined(_Z8F0433) || defined(_Z8F0232) || defined(_Z8F0233) || defined(_Z8F0132) || defined(_Z8F0133)
#undef EZ8_NVDS
#endif

#if defined(_Z8F083A) || defined(_Z8F043A)
#define EZ8_ADC_NEW
#endif

/*      Interrupt vectors */
#if defined(ENCORE_VECTORS)
#define  RESET     0
#define  WDT       1
#define  TRAP      2

#if defined(EZ8_TIMER3)
#define  TIMER2    3
#endif

#define  TIMER1    4
#define  TIMER0    5

#if defined(EZ8_UART0)
#define  UART0_RX  6
#define  UART0_TX  7
#endif

#if defined(EZ8_I2C)
#define  I2C       8
#endif

#if defined(EZ8_SPI)
#define  SPI       9
#endif

#if  defined(EZ8_ADC)
#define  ADC       10
#endif

#define  P7AD      11
#define  P6AD      12
#define  P5AD      13
#define  P4AD      14
#define  P3AD      15
#define  P2AD      16
#define  P1AD      17
#define  P0AD      18

#if defined(EZ8_TIMER4)
#define  TIMER3    19
#endif

#if defined(EZ8_UART1)
#define  UART1_RX  20
#define  UART1_TX  21
#endif

#if defined(EZ8_DMA)
#define  DMA       22
#endif


#if !defined(EZ8_PORT1)
#define  C3        23
#define  C2        24
#define  C1        25
#define  C0        26
#endif

#endif


#if defined(ENCORE_XP_VECTORS)
#define  RESET     0
#define  WDT       1
#define  TRAP      2

#if defined(EZ8_TIMER3)
#define  TIMER2    3
#endif

#define  TIMER1    4
#define  TIMER0    5

#if defined(EZ8_UART0)
#define  UART0_RX  6
#define  UART0_TX  7
#endif

#if defined(EZ8_I2C)
#define  I2C       8
#endif

#if defined(EZ8_SPI)
#define  SPI       9
#endif

#if  defined(EZ8_ADC) || defined(EZ8_ADC_NEW)
#define  ADC       10
#endif

#define  P7AD      11
#define  P6AD      12
#define  P5AD      13
#define  P4AD      14
#define  P3AD      15
#define  P2AD      16
#define  P1AD      17
#define  P0AD      18

#if defined(EZ8_TIMER4)
#define  TIMER3    19
#endif

#if defined(EZ8_UART1)
#define  UART1_RX  20
#define  UART1_TX  21
#endif

#if defined(EZ8_DMA)
#define  DMA       22
#endif

#if !defined(EZ8_PORT1)
#define  C3        23
#define  C2        24
#define  C1        25
#define  C0        26
#endif

#define  POTRAP    28
#define  WOTRAP    29
#endif


#if defined(ENCORE_XP16K_VECTORS)
#define  RESET     0
#define  WDT       1
#define  TRAP      2

#if defined(EZ8_TIMER3)
#define  TIMER2    3
#endif

#define  TIMER1    4
#define  TIMER0    5

#if defined(EZ8_UART0)
#define  UART0_RX  6
#define  UART0_TX  7
#endif

#if defined(EZ8_I2C)
#define  I2C       8
#endif

#if defined(EZ8_ESPI)
#define  SPI       9
#endif

#if  defined(EZ8_ADC_NEW)
#define  ADC       10
#endif

#define  P7AD      11
#define  P6AD      12
#define  P5AD      13
#define  P4AD      14
#define  P3AD      15
#define  P2AD      16
#define  P1AD      17
#define  P0AD      18

#if defined(EZ8_MCT)
#define  MCT       20
#endif

#if defined(EZ8_UART1)
#define  UART1_RX  21
#define  UART1_TX  22
#endif

#define  C3        23
#define  C2        24
#define  C1        25
#define  C0        26
#define  POTRAP    28
#define  WOTRAP    29
#endif


#if defined(ENCORE_MC_VECTORS)
#define  RESET     0
#define  WDT       1
#define  TRAP      2
#define  PWMTIMER  3
#define  PWMFAULT  4

#if defined(EZ8_ADC_NEW)
#define  ADC       5
#endif

#define  CMP       6
#define  TIMER0    7

#if defined(EZ8_UART0)
#define  UART0_RX  8
#define  UART0_TX  9
#endif

#if defined(EZ8_SPI)
#define  SPI       10
#endif

#if defined(EZ8_I2C)
#define  I2C       11
#endif

#define  C0        13
#define  PB        14
#define  P7A       15
#define  P3A       15
#define  P6A       16
#define  P2A       16
#define  P5A       17
#define  P1A       17
#define  P4A       18
#define  P0A       18
#define  POTRAP    28
#define  WOTRAP    29
#endif 

/* For ZSL */

#ifdef EZ8_UART0
#define UART0_RX_IVECT			UART0_RX
#define UART0_TX_IVECT			UART0_TX
#endif

#ifdef EZ8_UART1						
#define UART1_RX_IVECT			UART1_RX
#define UART1_TX_IVECT			UART1_TX
#endif

#define PA7_IVECT			PAD7_IVECT
#define PA6_IVECT			PAD6_IVECT
#define PA5_IVECT			PAD5_IVECT
#define PA4_IVECT			PAD4_IVECT
#define PA3_IVECT			PAD3_IVECT
#define PA2_IVECT			PAD2_IVECT
#define PA1_IVECT			PAD1_IVECT
#define PA0_IVECT			PAD0_IVECT
							
#define PD7_IVECT			PAD7_IVECT
#define PD6_IVECT			PAD6_IVECT
#define PD5_IVECT			PAD5_IVECT
#define PD4_IVECT			PAD4_IVECT
#define PD3_IVECT			PAD3_IVECT
#define PD2_IVECT			PAD2_IVECT
#define PD1_IVECT			PAD1_IVECT
#define PD0_IVECT			PAD0_IVECT

#define PAD7_IVECT			P7AD
#define PAD6_IVECT			P6AD
#define PAD5_IVECT			P5AD
#define PAD4_IVECT			P4AD
#define PAD3_IVECT			P3AD
#define PAD2_IVECT			P2AD
#define PAD1_IVECT			P1AD
#define PAD0_IVECT			P0AD

#ifndef EZ8_PORT1
#define PC3_IVECT			C3
#define PC2_IVECT			C2
#define PC1_IVECT			C1
#define PC0_IVECT			C0
#endif

/*      Special Function Registers */
#define T0      (*(unsigned int volatile far*)0xF00)               // Reset = 0x0000 Timer 0
#define T0H     (*(unsigned char volatile far*)0xF00)              // Reset = 0x00 Timer 0 High
#define T0L     (*(unsigned char volatile far*)0xF01)              // Reset = 0x01 Timer 0 Low
#define T0CP    (*(unsigned int volatile far*)0xF02)               // Reset = 0xFFFF Timer 0 Compare
#define T0CPH   (*(unsigned char volatile far*)0xF02)              // Reset = 0xFF Timer 0 Compare High
#define T0R     (*(unsigned int volatile far*)0xF02)               // Reset = 0xFFFF Timer 0 Compare
#define T0RH    (*(unsigned char volatile far*)0xF02)              // Reset = 0xFF Timer 0 Compare High
#define T0CPL   (*(unsigned char volatile far*)0xF03)              // Reset = 0xFF Timer 0 Compare Low
#define T0RL    (*(unsigned char volatile far*)0xF03)              // Reset = 0xFF Timer 0 Compare Low
#if defined(_Z8F1680)
#define T0PWM0  (*(unsigned int volatile far*)0xF04)               // Reset = 0x0000 Timer 0 PWM0
#define T0PWM0H (*(unsigned char volatile far*)0xF04)              // Reset = 0x00 Timer 0 PWM0 High
#define T0PWM0L (*(unsigned char volatile far*)0xF05)              // Reset = 0x00 Timer 0 PMW0 Low
#else
#define T0PWM   (*(unsigned int volatile far*)0xF04)               // Reset = 0x0000 Timer 0 PWM
#define T0PWMH  (*(unsigned char volatile far*)0xF04)              // Reset = 0x00 Timer 0 PWM High
#define T0PWML  (*(unsigned char volatile far*)0xF05)              // Reset = 0x00 Timer 0 PMW Low
#endif

#if defined(_Z8F642) || defined(_Z8F04A) || defined(_Z8F08) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680)
#define T0CTL0  (*(unsigned char volatile far*)0xF06)              // Reset = 0x00 Timer 0 Control 0
#define T0CTL1  (*(unsigned char volatile far*)0xF07)              // Reset = 0x00 Timer 0 Control 1
#endif
#define T0CTL   (*(unsigned char volatile far*)0xF07)              // Reset = 0x00 Timer 0 Control

#if defined(_Z8FMC16)
#define ADCTCAP   (*(unsigned int volatile far*)0xF08)             // Reset = 0xXX Timer 0 Capture Register
#define ADCTCAP_H (*(unsigned char volatile far*)0xF08)            // Reset = 0xXX Timer 0 Capture Register High Byte
#define ADCTCAP_L (*(unsigned char volatile far*)0xF09)            // Reset = 0x00 Timer 0 Capture Register Low Byte
#endif

#if defined(_Z8F1680)
#define T0PWM1  (*(unsigned int volatile far*)0xF20)               // Reset = 0x0000 Timer 0 PWM1
#define T0PWM1H (*(unsigned char volatile far*)0xF20)              // Reset = 0x00 Timer 0 PWM1 High
#define T0PWM1L (*(unsigned char volatile far*)0xF21)              // Reset = 0x00 Timer 0 PMW1 Low
#define T0CTL2  (*(unsigned char volatile far*)0xF22)              // Reset = 0x00 Timer 0 Control 2
#define T0STA   (*(unsigned char volatile far*)0xF23)              // Reset = 0x00 Timer 0 Status
#define T0NFC  (*(unsigned char volatile far*)0xF2C)               // Reset = 0x00 Timer 0 Noise Filter Control
#endif

#ifdef EZ8_TIMER2
#define T1      (*(unsigned int volatile far*)0xF08)               // Reset = 0x0000 Timer 1
#define T1H     (*(unsigned char volatile far*)0xF08)              // Reset = 0x00 Timer 1 High
#define T1L     (*(unsigned char volatile far*)0xF09)              // Reset = 0x01 Timer 1 Low
#define T1CP    (*(unsigned int volatile far*)0xF0A)               // Reset = 0xFFFF Timer 1 Compare
#define T1CPH   (*(unsigned char volatile far*)0xF0A)              // Reset = 0xFF Timer 1 Compare High
#define T1R     (*(unsigned int volatile far*)0xF0A)               // Reset = 0xFFFF Timer 1 Compare
#define T1RH    (*(unsigned char volatile far*)0xF0A)              // Reset = 0xFF Timer 1 Compare High
#define T1CPL   (*(unsigned char volatile far*)0xF0B)              // Reset = 0xFF Timer 1 Compare Low
#define T1RL    (*(unsigned char volatile far*)0xF0B)              // Reset = 0xFF Timer 1 Compare Low
#if defined(_Z8F1680)
#define T1PWM0  (*(unsigned int volatile far*)0xF0C)               // Reset = 0x0000 Timer 1 PWM0
#define T1PWM0H (*(unsigned char volatile far*)0xF0C)              // Reset = 0x00 Timer 1 PWM0 High
#define T1PWM0L (*(unsigned char volatile far*)0xF0D)              // Reset = 0x00 Timer 1 PWM0 Low
#else
#define T1PWM   (*(unsigned int volatile far*)0xF0C)               // Reset = 0x0000 Timer 1 PWM
#define T1PWMH  (*(unsigned char volatile far*)0xF0C)              // Reset = 0x00 Timer 1 PWM High
#define T1PWML  (*(unsigned char volatile far*)0xF0D)              // Reset = 0x00 Timer 1 PWM Low
#endif
#if defined(_Z8F642) || defined(_Z8F04A) || defined(_Z8F08) || defined(_Z8F04) || defined(_Z8F1680)
#define T1CTL0  (*(unsigned char volatile far*)0xF0E)              // Reset = 0x00 Timer 1 Control 0
#define T1CTL1  (*(unsigned char volatile far*)0xF0F)              // Reset = 0x00 Timer 1 Control 1
#endif
#define T1CTL   (*(unsigned char volatile far*)0xF0F)              // Reset = 0x00 Timer 1 Control
#if defined(_Z8F1680)
#define T1PWM1  (*(unsigned int volatile far*)0xF24)               // Reset = 0x0000 Timer 1 PWM1
#define T1PWM1H (*(unsigned char volatile far*)0xF24)              // Reset = 0x00 Timer 1 PWM1 High
#define T1PWM1L (*(unsigned char volatile far*)0xF25)              // Reset = 0x00 Timer 1 PMW1 Low
#define T1CTL2  (*(unsigned char volatile far*)0xF26)              // Reset = 0x00 Timer 1 Control 2
#define T1STA   (*(unsigned char volatile far*)0xF27)              // Reset = 0x00 Timer 1 Status
#define T1NFC  (*(unsigned char volatile far*)0xF2D)               // Reset = 0x00 Timer 1 Noise Filter Control
#endif
#endif

#ifdef EZ8_TIMER3
#define T2      (*(unsigned int volatile far*)0xF10)               // Reset = 0x0000 Timer 2
#define T2H     (*(unsigned char volatile far*)0xF10)              // Reset = 0x00 Timer 2 High
#define T2L     (*(unsigned char volatile far*)0xF11)              // Reset = 0x01 Timer 2 Low
#define T2CP    (*(unsigned int volatile far*)0xF12)               // Reset = 0xFFFF Timer 2 Compare
#define T2CPH   (*(unsigned char volatile far*)0xF12)              // Reset = 0xFF Timer 2 Compare High
#define T2R     (*(unsigned int volatile far*)0xF12)               // Reset = 0xFFFF Timer 2 Compare
#define T2RH    (*(unsigned char volatile far*)0xF12)              // Reset = 0xFF Timer 2 Compare High
#define T2CPL   (*(unsigned char volatile far*)0xF13)              // Reset = 0xFF Timer 2 Compare Low
#define T2RL    (*(unsigned char volatile far*)0xF13)              // Reset = 0xFF Timer 2 Compare Low
#if defined(_Z8F1680)
#define T2PWM0  (*(unsigned int volatile far*)0xF14)               // Reset = 0x0000 Timer 2 PWM0
#define T2PWM0H (*(unsigned char volatile far*)0xF14)              // Reset = 0x00 Timer 2 PWM0 High
#define T2PWM0L (*(unsigned char volatile far*)0xF15)              // Reset = 0x00 Timer 2 PWM0 Low
#else
#define T2PWM   (*(unsigned int volatile far*)0xF14)               // Reset = 0x0000 Timer 2 PWM
#define T2PWMH  (*(unsigned char volatile far*)0xF14)              // Reset = 0x00 Timer 2 PWM High
#define T2PWML  (*(unsigned char volatile far*)0xF15)              // Reset = 0x00 Timer 2 PWM Low
#endif
#if defined(_Z8F642) || defined(_Z8F1680)
#define T2CTL0  (*(unsigned char volatile far*)0xF16)              // Reset = 0x00 Timer 2 Control 0
#define T2CTL1  (*(unsigned char volatile far*)0xF17)              // Reset = 0x00 Timer 2 Control 1
#endif
#define T2CTL   (*(unsigned char volatile far*)0xF17)              // Reset = 0x00 Timer 2 Control
#if defined(_Z8F1680)
#define T2PWM1  (*(unsigned int volatile far*)0xF28)               // Reset = 0x0000 Timer 2 PWM1
#define T2PWM1H (*(unsigned char volatile far*)0xF28)              // Reset = 0x00 Timer 2 PWM1 High
#define T2PWM1L (*(unsigned char volatile far*)0xF29)              // Reset = 0x00 Timer 2 PMW1 Low
#define T2CTL2  (*(unsigned char volatile far*)0xF2A)              // Reset = 0x00 Timer 2 Control 2
#define T2STA   (*(unsigned char volatile far*)0xF2B)              // Reset = 0x00 Timer 2 Status
#define T2NFC  (*(unsigned char volatile far*)0xF2E)               // Reset = 0x00 Timer 2 Noise Filter Control
#endif
#endif

#ifdef EZ8_TIMER4
#define T3      (*(unsigned int volatile far*)0xF18)               // Reset = 0x0000 Timer 3
#define T3H     (*(unsigned char volatile far*)0xF18)              // Reset = 0x00 Timer 3 High
#define T3L     (*(unsigned char volatile far*)0xF19)              // Reset = 0x01 Timer 3 Low
#define T3CP    (*(unsigned int volatile far*)0xF1A)               // Reset = 0xFFFF Timer 3 Compare
#define T3CPH   (*(unsigned char volatile far*)0xF1A)              // Reset = 0xFF Timer 3 Compare High
#define T3R     (*(unsigned int volatile far*)0xF1A)               // Reset = 0xFFFF Timer 3 Compare
#define T3RH    (*(unsigned char volatile far*)0xF1A)              // Reset = 0xFF Timer 3 Compare High
#define T3CPL   (*(unsigned char volatile far*)0xF1B)              // Reset = 0xFF Timer 3 Compare Low
#define T3RL    (*(unsigned char volatile far*)0xF1B)              // Reset = 0xFF Timer 3 Compare Low
#define T3PWM   (*(unsigned int volatile far*)0xF1C)               // Reset = 0x0000 Timer 3 PWM
#define T3PWMH  (*(unsigned char volatile far*)0xF1C)              // Reset = 0x00 Timer 3 PWM High
#define T3PWML  (*(unsigned char volatile far*)0xF1D)              // Reset = 0x00 Timer 3 PWM Low
#ifdef _Z8F642
#define T3CTL0  (*(unsigned char volatile far*)0xF1E)              // Reset = 0x00 Timer 3 Control 0
#define T3CTL1  (*(unsigned char volatile far*)0xF1F)              // Reset = 0x00 Timer 3 Control 1
#endif
#define T3CTL   (*(unsigned char volatile far*)0xF1F)              // Reset = 0x00 Timer 3 Control
#endif  /* EZ8_TIMER4 */

#ifdef EZ8_PWM
#define PWMCTL0  (*(unsigned char volatile far*)0xF20)              // Reset = 0x00 PWM Control 0
#define PWMCTL1  (*(unsigned char volatile far*)0xF21)              // Reset = 0x00 PWM Control 1
#define PWMDB    (*(unsigned char volatile far*)0xF22)              // Reset = 0x00 PWM Dead Band
#define PWMMPF   (*(unsigned char volatile far*)0xF23)              // Reset = 0x00 PWM Min Pulse Width Filter
#define PWMFM    (*(unsigned char volatile far*)0xF24)              // Reset = 0x00 PWM Fault Mask
#define PWMFSTAT (*(unsigned char volatile far*)0xF25)              // Reset = 0x00 PWM Fault Status
#define PWMIN    (*(unsigned char volatile far*)0xF26)              // Reset = 0x00 PWM Input Sample
#define PWMOUT   (*(unsigned char volatile far*)0xF27)              // Reset = 0x00 PWM Output Control
#define PWMFCTL  (*(unsigned char volatile far*)0xF28)              // Reset = 0x00 PWM Fault Control
#define CSSHR    (*(unsigned char volatile far*)0xF29)              // Reset = 0x00 PWM Current-Sense Sample & Hold
#define PWMSHC   (*(unsigned char volatile far*)0xF29)              // Reset = 0x00 PWM Current-Sense ADC Trigger Control
#define PWM      (*(unsigned int volatile far*)0xF2C)               // Reset = 0xXXXX PWM
#define PWMH     (*(unsigned char volatile far*)0xF2C)              // Reset = 0xXX PWM High Byte 
#define PWML     (*(unsigned char volatile far*)0xF2D)              // Reset = 0xXX PWM Low Byte
#define PWMR     (*(unsigned int volatile far*)0xF2E)               // Reset = 0xFFFF PWM Reload
#define PWMRH    (*(unsigned char volatile far*)0xF2E)              // Reset = 0xFF PWM Reload High
#define PWMRL    (*(unsigned char volatile far*)0xF2F)              // Reset = 0xFF PWM Reload Low
#define PWMH0D   (*(unsigned int volatile far*)0xF30)               // Reset = 0x0000 PWM0 High Side Duty Cycle
#define PWMH0DH  (*(unsigned char volatile far*)0xF30)              // Reset = 0x00 PWM0 High Side Duty Cycle Hi Byte
#define PWMH0DL  (*(unsigned char volatile far*)0xF31)              // Reset = 0x00 PWM0 High Side Duty Cycle Lo Byte
#define PWML0D   (*(unsigned int volatile far*)0xF32)               // Reset = 0x0000 PWM0 Low Side Duty Cycle
#define PWML0DH  (*(unsigned char volatile far*)0xF32)              // Reset = 0x00 PWM0 Low Side Duty Cycle Hi Byte
#define PWML0DL  (*(unsigned char volatile far*)0xF33)              // Reset = 0x00 PWM0 Low Side Duty Cycle Lo Byte
#define PWMH1D   (*(unsigned int volatile far*)0xF34)               // Reset = 0x0000 PWM1 High Side Duty Cycle
#define PWMH1DH  (*(unsigned char volatile far*)0xF34)              // Reset = 0x00 PWM1 High Side Duty Cycle Hi Byte
#define PWMH1DL  (*(unsigned char volatile far*)0xF35)              // Reset = 0x00 PWM1 High Side Duty Cycle Lo Byte
#define PWML1D   (*(unsigned int volatile far*)0xF36)               // Reset = 0x0000 PWM1 Low Side Duty Cycle
#define PWML1DH  (*(unsigned char volatile far*)0xF36)              // Reset = 0x00 PWM1 Low Side Duty Cycle Hi Byte
#define PWML1DL  (*(unsigned char volatile far*)0xF37)              // Reset = 0x00 PWM1 Low Side Duty Cycle Lo Byte
#define PWMH2D   (*(unsigned int volatile far*)0xF38)               // Reset = 0x0000 PWM2 High Side Duty Cycle
#define PWMH2DH  (*(unsigned char volatile far*)0xF38)              // Reset = 0x00 PWM2 High Side Duty Cycle Hi Byte
#define PWMH2DL  (*(unsigned char volatile far*)0xF39)              // Reset = 0x00 PWM2 High Side Duty Cycle Lo Byte
#define PWML2D   (*(unsigned int volatile far*)0xF3A)               // Reset = 0x0000 PWM2 Low Side Duty Cycle
#define PWML2DH  (*(unsigned char volatile far*)0xF3A)              // Reset = 0x00 PWM2 Low Side Duty Cycle Hi Byte
#define PWML2DL  (*(unsigned char volatile far*)0xF3B)              // Reset = 0x00 PWM2 Low Side Duty Cycle Lo Byte
#endif

#ifdef EZ8_UART0
#define U0D     (*(unsigned char volatile far*)0xF40)              // Reset = 0xXX UART0 Data
#define U0TXD   (*(unsigned char volatile far*)0xF40)              // Reset = 0xXX UART0 Data
#define U0RXD   (*(unsigned char volatile far*)0xF40)              // Reset = 0xXX UART0 Data
#define U0STAT0 (*(unsigned char volatile far*)0xF41)              // Reset = 0x06 UART0 Status 0
#define U0CTL0  (*(unsigned char volatile far*)0xF42)              // Reset = 0x00 UART0 Control 0
#define U0CTL1  (*(unsigned char volatile far*)0xF43)              // Reset = 0x00 UART0 Control 1
#if defined(_Z8FMC16) || defined(_Z8F1680)
#define U0MDSTAT (*(unsigned char volatile far*)0xF44)             // Reset = 0x00 UART0 Mode Select and Status
#else
#define U0STAT1 (*(unsigned char volatile far*)0xF44)              // Reset = 0x00 UART0 Status 1
#endif
#if  defined(_Z8F642) || defined(_Z8F04A) || defined(_Z8F08) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680)
#define U0ADDR  (*(unsigned char volatile far*)0xF45)              // Reset = 0x00 UART0 Address Compare Register
#endif
#define U0BR    (*(unsigned int volatile far*)0xF46)               // Reset = 0xFFFF UARTO Baud Rate
#define U0BRH   (*(unsigned char volatile far*)0xF46)              // Reset = 0xFF UARTO Baud Rate High
#define U0BRL   (*(unsigned char volatile far*)0xF47)              // Reset = 0xFF UARTO Baud Rate Low
#endif

#ifdef EZ8_UART1
#define U1D     (*(unsigned char volatile far*)0xF48)              // Reset = 0xXX UART 1 Data
#define U1TXD   (*(unsigned char volatile far*)0xF48)              // Reset = 0xXX UART 1 Data
#define U1RXD   (*(unsigned char volatile far*)0xF48)              // Reset = 0xXX UART 1 Data
#define U1STAT0 (*(unsigned char volatile far*)0xF49)              // Reset = 0x06 UART1 Status 0
#define U1CTL0  (*(unsigned char volatile far*)0xF4A)              // Reset = 0x00 UART1 Control 0
#define U1CTL1  (*(unsigned char volatile far*)0xF4B)              // Reset = 0x00 UART1 Control 1
#if defined(_Z8F1680)
#define U1MDSTAT (*(unsigned char volatile far*)0xF4C)             // Reset = 0x00 UART1 Mode Select and Status
#else
#define U1STAT1 (*(unsigned char volatile far*)0xF4C)              // Reset = 0x00 UARR1 Status 1
#endif
#if defined(_Z8F642) || defined(_Z8F1680)
#define U1ADDR  (*(unsigned char volatile far*)0xF4D)              // Reset = 0x00 UART1 Address Compare Register
#endif
#define U1BR    (*(unsigned int volatile far*)0xF4E)               // Reset = 0xFFFF UART1 Baud Rate
#define U1BRH   (*(unsigned char volatile far*)0xF4E)              // Reset = 0xFF UART1 Baud Rate High
#define U1BRL   (*(unsigned char volatile far*)0xF4F)              // Reset = 0xFF UART1 Baud Rate Low
#endif

#ifdef EZ8_I2C
#define I2CD    (*(unsigned char volatile far*)0xF50)              // Reset = 0x00 I2C Data
#define I2CDATA (*(unsigned char volatile far*)0xF50)              // Reset = 0x00 I2C Data
#if defined(_Z8FMC16) || defined(_Z8F1680)
#define I2CISTAT (*(unsigned char volatile far*)0xF51)             // Reset = 0x80 I2C Interrupt Status
#else
#define I2CSTAT (*(unsigned char volatile far*)0xF51)              // Reset = 0x80 I2C Status
#endif
#define I2CCTL  (*(unsigned char volatile far*)0xF52)              // Reset = 0x00 I2C Control
#define I2CBR   (*(unsigned int volatile far*)0xF53)               // Reset = 0xFFFF I2C Baud Reload
#define I2CBRH  (*(unsigned char volatile far*)0xF53)              // Reset = 0xFF I2C Baud Reload High
#define I2CBRL  (*(unsigned char volatile far*)0xF54)              // Reset = 0xFF I2C Baud Reload Low

#if  defined(_Z8F642) || defined(_Z8F08)
#define I2CDST  (*(unsigned char volatile far*)0xF55)              // Reset = 0xC0 I2C Diagnostic State
#define I2CDIAG (*(unsigned char volatile far*)0xF56)              // Reset = 0x00 I2C Diagnostic
#endif

#if defined(_Z8FMC16) || defined(_Z8F1680)
#define I2CSTATE (*(unsigned char volatile far*)0xF55)             // Reset = 0x00 I2C State Register
#define I2CMODE  (*(unsigned char volatile far*)0xF56)             // Reset = 0x00 I2C Mode Register
#define I2CSLVAD (*(unsigned char volatile far*)0xF57)             // Reset = 0x00 I2C Slave Address Register
#endif
#endif

#ifdef EZ8_SPI
#define SPID    (*(unsigned char volatile far*)0xF60)              // Reset = 0xXX SPI Data
#define SPIDATA (*(unsigned char volatile far*)0xF60)              // Reset = 0xXX SPI Data
#define SPICTL  (*(unsigned char volatile far*)0xF61)              // Reset = 0x00 SPI Control
#define SPISTAT (*(unsigned char volatile far*)0xF62)              // Reset = 0x00 SPI Status
#define SPSTAT  (*(unsigned char volatile far*)0xF62)              // Reset = 0x00 SPI Status
#define SPIMODE (*(unsigned char volatile far*)0xF63)              // Reset = 0x00 SPI Mode

#if defined(_Z8F642) || defined(_Z8F08) || defined(_Z8FMC16)
#define SPIDST  (*(unsigned char volatile far*)0xF64)              // Reset = 0x00 SPI Diagnostic State
#endif

#define SPIBR   (*(unsigned int volatile far*)0xF66)               // Reset = 0xFFFF SPI Baud Rate
#define SPIBRH  (*(unsigned char volatile far*)0xF66)              // Reset = 0xFF SPI Baud Rate High
#define SPIBRL  (*(unsigned char volatile far*)0xF67)              // Reset = 0xFF SPI Baud Rate Low
#endif

#ifdef EZ8_ESPI
#define ESPIDATA  (*(unsigned char volatile far*)0xF60)              // Reset = 0xXX ESPI Data
#define ESPITDCR  (*(unsigned char volatile far*)0xF61)              // Reset = 0x00 ESPI Transmit Data Command
#define ESPICTL   (*(unsigned char volatile far*)0xF62)              // Reset = 0x00 ESPI Control
#define ESPIMODE  (*(unsigned char volatile far*)0xF63)              // Reset = 0x00 ESPI Mode
#define ESPISTAT  (*(unsigned char volatile far*)0xF64)              // Reset = 0x81 ESPI Status
#define ESPISTATE (*(unsigned char volatile far*)0xF65)              // Reset = 0x00 ESPI State
#define ESPIBR    (*(unsigned int volatile far*)0xF66)               // Reset = 0xFFFF ESPI Baud Rate
#define ESPIBRH   (*(unsigned char volatile far*)0xF66)              // Reset = 0xFF ESPI Baud Rate High
#define ESPIBRL   (*(unsigned char volatile far*)0xF67)              // Reset = 0xFF ESPI Baud Rate Low
#endif


#ifdef EZ8_ADC
#if defined(_Z8F04A) || defined(_Z8F04)
#define ADCCTL0 (*(unsigned char volatile far*)0xF70)              // Reset = 0x00 ADC Control 0
#define ADCCTL1 (*(unsigned char volatile far*)0xF71)              // Reset = 0x80 ADC Control 1
#else
#define ACTL    (*(unsigned char volatile far*)0xF70)              // Reset = 0x00 ADC Control
#define ADCCTL  (*(unsigned char volatile far*)0xF70)              // Reset = 0x00 ADC Control
#endif
#define ADHR    (*(unsigned char volatile far*)0xF72)              // Reset = 0xXX ADC Data High
#define ADCD    (*(unsigned int volatile far*)0xF72)               // Reset = 0xXXXX ADC Data
#define ADCD_H  (*(unsigned char volatile far*)0xF72)              // Reset = 0xXX ADC Data High
#define ADLR    (*(unsigned char volatile far*)0xF73)              // Reset = 0xXX ADC Data Low
#define ADCDL   (*(unsigned char volatile far*)0xF73)              // Reset = 0xXX ADC Data Low
#define ADCD_L  (*(unsigned char volatile far*)0xF73)              // Reset = 0xXX ADC Data Low

#if defined(_Z8F04A)
#define ADCTHH  (*(unsigned char volatile far*)0xF74)              // Reset = 0xFF ADC High Threshold High Byte
#define ADCTLH  (*(unsigned char volatile far*)0xF76)              // Reset = 0x00 ADC Low Threshold High Byte
#endif

#endif

#ifdef EZ8_ADC_NEW 
#define ADCCTL0 (*(unsigned char volatile far*)0xF70)              // Reset = 0x00 ADC Control 0
#if !defined(_Z8F0830A)
#define ADCRD_H (*(unsigned char volatile far*)0xF71)              // Reset = 0xXX ADC Raw Data High Byte
#endif
#define ADCD    (*(unsigned int volatile far*)0xF72)               // Reset = 0xXXXX ADC Data
#define ADCD_H  (*(unsigned char volatile far*)0xF72)              // Reset = 0xXX ADC Data High
#define ADCD_L  (*(unsigned char volatile far*)0xF73)              // Reset = 0xXX ADC Data Low
#define ADCSST  (*(unsigned char volatile far*)0xF74)              // Reset = 0x0A ADC Sample Settling Time
#define ADCST   (*(unsigned char volatile far*)0xF75)              // Reset = 0x14 ADC Sample Time
#if !defined(_Z8F0830S)
#define ADCCP   (*(unsigned char volatile far*)0xF76)              // Reset = 0x00 ADC Clock Prescale
#endif
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define PWRCTL0 (*(unsigned char volatile far*)0xF80)              // Reset = 0x00 Power Control 0

#if (defined(_Z8F04A) && !defined(_Z8F04A_8PIN)) || (defined(_Z8F04) && !defined(_Z8F04_8PIN) && !defined(_Z8F0823_8PIN)) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define LEDEN   (*(unsigned char volatile far*)0xF82)              // Reset = 0x00 LED Drive Enable
#define LEDLVL  (*(unsigned int volatile far*)0xF83)               // Reset = 0x0000 LED Drive Level
#define LEDLVLH (*(unsigned char volatile far*)0xF83)              // Reset = 0x00 LED Drive Level High Byte
#define LEDLVLL (*(unsigned char volatile far*)0xF84)              // Reset = 0x00 LED Drive Level Low Byte
#endif

#if defined(_Z8F1680)
#define OSCCTL0 (*(unsigned char volatile far*)0xF86)              // Reset = 0xA0 Oscillator Control 0
#define OSCCTL1 (*(unsigned char volatile far*)0xF87)              // Reset = 0x00 Oscillator Control 1
#else
#define OSCCTL  (*(unsigned char volatile far*)0xF86)              // Reset = 0x20 Oscillator Control
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8F1680)
#define CMP0    (*(unsigned char volatile far*)0xF90)              // Reset = 0x14 Comparator 0 Control
#endif

#ifdef EZ8_CMP1
#define CMP1    (*(unsigned char volatile far*)0xF91)              // Reset = 0x14 Comparator 1 Control
#endif
#endif

#if defined(_Z8FMC16)
#define OSCCTL  (*(unsigned char volatile far*)0xF86)              // Reset = 0x20 Oscillator Control
#define OSCDIV  (*(unsigned char volatile far*)0xF87)              // Reset = 0x00 Oscillator Divide
#define CMPOPC  (*(unsigned char volatile far*)0xF90)              // Reset = 0x00 Comparator and Opamp Control
#endif

#ifdef EZ8_MCT
#define MCTHL    (*(unsigned int volatile far*)0xFA0)               // Reset = 0x0000 MCT
#define MCTH     (*(unsigned char volatile far*)0xFA0)              // Reset = 0x00 MCT High
#define MCTL     (*(unsigned char volatile far*)0xFA1)              // Reset = 0x00 MCT Low
#define MCTR     (*(unsigned int volatile far*)0xFA2)               // Reset = 0xFFFF MCT Reload
#define MCTRH    (*(unsigned char volatile far*)0xFA2)              // Reset = 0xFF MCT Reload High
#define MCTRL    (*(unsigned char volatile far*)0xFA3)              // Reset = 0xFF MCT Reload Low
#define MCTSA    (*(unsigned char volatile far*)0xFA4)              // Reset = 0xXX MCT Sub Address
#define MCTSR0   (*(unsigned char volatile far*)0xFA5)              // Reset = 0xXX MCT Sub Register 0
#define MCTSR1   (*(unsigned char volatile far*)0xFA6)              // Reset = 0xXX MCT Sub Register 1
#define MCTSR2   (*(unsigned char volatile far*)0xFA7)              // Reset = 0xXX MCT Sub Register 2

#define __MCT_CONTROL             0x00
#define __MCT_CHANNEL_STATUS      0x01
#define __MCT_CHANNEL_A           0x02
#define __MCT_CHANNEL_B           0x03
#define __MCT_CHANNEL_C           0x04
#define __MCT_CHANNEL_D           0x05

#define MCTCTL0	  (((MCTSA) =          __MCT_CONTROL),((MCTSR0)))
#define MCTCTL1	  (((MCTSA) =          __MCT_CONTROL),((MCTSR1)))
#define MCTCHS0	  (((MCTSA) =   __MCT_CHANNEL_STATUS),((MCTSR0)))
#define MCTCHS1	  (((MCTSA) =   __MCT_CHANNEL_STATUS),((MCTSR1)))
#define MCTCHACTL (((MCTSA) =        __MCT_CHANNEL_A),((MCTSR2)))
#define MCTCHBCTL (((MCTSA) =        __MCT_CHANNEL_B),((MCTSR2)))
#define MCTCHCCTL (((MCTSA) =        __MCT_CHANNEL_C),((MCTSR2)))
#define MCTCHDCTL (((MCTSA) =        __MCT_CHANNEL_D),((MCTSR2)))
#define MCTCHAH   (((MCTSA) =        __MCT_CHANNEL_A),((MCTSR0)))
#define MCTCHBH   (((MCTSA) =        __MCT_CHANNEL_B),((MCTSR0)))
#define MCTCHCH   (((MCTSA) =        __MCT_CHANNEL_C),((MCTSR0)))
#define MCTCHDH   (((MCTSA) =        __MCT_CHANNEL_D),((MCTSR0)))
#define MCTCHAL   (((MCTSA) =        __MCT_CHANNEL_A),((MCTSR1)))
#define MCTCHBL   (((MCTSA) =        __MCT_CHANNEL_B),((MCTSR1)))
#define MCTCHCL   (((MCTSA) =        __MCT_CHANNEL_C),((MCTSR1)))
#define MCTCHDL   (((MCTSA) =        __MCT_CHANNEL_D),((MCTSR1)))

#endif

#ifdef EZ8_DMA
#define D0CTL     (*(unsigned char volatile far*)0xFB0)            // Reset = 0x00 DMA0 Control
#define DMA0CTL   (*(unsigned char volatile far*)0xFB0)            // Reset = 0x00 DMA0 Control
#define D0IO      (*(unsigned char volatile far*)0xFB1)            // Reset = 0xXX DMA0 I/O Address
#define DMA0IO    (*(unsigned char volatile far*)0xFB1)            // Reset = 0xXX DMA0 I/O Address
#define D0HIGH    (*(unsigned char volatile far*)0xFB2)            // Reset = 0xXX DMA0 End/Start Address High
#define DMA0H     (*(unsigned char volatile far*)0xFB2)            // Reset = 0xXX DMA0 End/Start Address High
#define D0START   (*(unsigned char volatile far*)0xFB3)            // Reset = 0xXX DMA0 Start Address Low
#define DMA0START (*(unsigned char volatile far*)0xFB3)            // Reset = 0xXX DMA0 Start Address Low
#define D0END     (*(unsigned char volatile far*)0xFB4)            // Reset = 0xXX DMA0 End Address Low
#define DMA0END   (*(unsigned char volatile far*)0xFB4)            // Reset = 0xXX DMA0 End Address Low

#define D1CTL     (*(unsigned char volatile far*)0xFB8)            // Reset = 0x00 DMA1 Control
#define DMA1CTL   (*(unsigned char volatile far*)0xFB8)            // Reset = 0x00 DMA1 Control
#define D1IO      (*(unsigned char volatile far*)0xFB9)            // Reset = 0xXX DMA1 I/O Address
#define DMA1IO    (*(unsigned char volatile far*)0xFB9)            // Reset = 0xXX DMA1 I/O Address
#define D1HIGH    (*(unsigned char volatile far*)0xFBA)            // Reset = 0xXX DMA1 End/Start Address High
#define DMA1H     (*(unsigned char volatile far*)0xFBA)            // Reset = 0xXX DMA1 End/Start Address High
#define D1START   (*(unsigned char volatile far*)0xFBB)            // Reset = 0xXX DMA1 Start Address Low
#define DMA1START (*(unsigned char volatile far*)0xFBB)            // Reset = 0xXX DMA1 Start Address Low
#define D1END     (*(unsigned char volatile far*)0xFBC)            // Reset = 0xXX DMA1 End Address Low
#define DMA1END   (*(unsigned char volatile far*)0xFBC)            // Reset = 0xXX DMA1 End Address Low

#define DAADDR    (*(unsigned char volatile far*)0xFBD)            // Reset = 0xXX ADC DMA Address
#define DMAA_ADDR (*(unsigned char volatile far*)0xFBD)            // Reset = 0xXX ADC DMA Address
#define DACTL     (*(unsigned char volatile far*)0xFBE)            // Reset = 0x00 ADC DMA Control
#define DMAACTL   (*(unsigned char volatile far*)0xFBE)            // Reset = 0x00 ADC DMA Control
#define DSTAT     (*(unsigned char volatile far*)0xFBF)            // Reset = 0x00 DMA Status
#define DMAASTAT  (*(unsigned char volatile far*)0xFBF)            // Reset = 0x00 DMA Status
#endif


#define IRQ0    (*(unsigned char volatile far*)0xFC0)              // Reset = 0x00 Interrupt Request 0
#define IRQ0E0  (*(unsigned char volatile far*)0xFC1)              // Reset = 0x00 IRQ0 Enable 0
#define IRQ0EN  (*(unsigned int volatile far*)0xFC1)               // Reset = 0x0000 IRQ0 Enable
#define IRQ0ENH (*(unsigned char volatile far*)0xFC1)              // Reset = 0x00 IRQ0 Enable 0
#define IRQ0E1  (*(unsigned char volatile far*)0xFC2)              // Reset = 0x00 IRQ0 Enable 1
#define IRQ0ENL (*(unsigned char volatile far*)0xFC2)              // Reset = 0x00 IRQ0 Enable 1

#define IRQ1    (*(unsigned char volatile far*)0xFC3)              // Reset = 0x00 Interrupt Request 1
#define IRQ1E0  (*(unsigned char volatile far*)0xFC4)              // Reset = 0x00 IRQ1 Enable 0
#define IRQ1EN  (*(unsigned int volatile far*)0xFC4)               // Reset = 0x0000 IRQ1 Enable
#define IRQ1ENH (*(unsigned char volatile far*)0xFC4)              // Reset = 0x00 IRQ1 Enable 0
#define IRQ1E1  (*(unsigned char volatile far*)0xFC5)              // Reset = 0x00 IRQ1 Enable 1
#define IRQ1ENL (*(unsigned char volatile far*)0xFC5)              // Reset = 0x00 IRQ1 Enable 1

#ifdef EZ8_IRQ3
#define IRQ2    (*(unsigned char volatile far*)0xFC6)              // Reset = 0x00 Interrupt Request 2
#define IRQ2E0  (*(unsigned char volatile far*)0xFC7)              // Reset = 0x00 IRQ2 Enable 0
#define IRQ2EN  (*(unsigned int volatile far*)0xFC7)               // Reset = 0x0000 IRQ2 Enable
#define IRQ2ENH (*(unsigned char volatile far*)0xFC7)              // Reset = 0x00 IRQ2 Enable 0
#define IRQ2E1  (*(unsigned char volatile far*)0xFC8)              // Reset = 0xXX IRQ2 Enable 1
#define IRQ2ENL (*(unsigned char volatile far*)0xFC8)              // Reset = 0xXX IRQ2 Enable 1
#endif

#ifndef _Z8FMC16
#define IRQES   (*(unsigned char volatile far*)0xFCD)              // Reset = 0x00 Interrupt Edge Select
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define IRQSS   (*(unsigned char volatile far*)0xFCE)              // Reset = 0x00 Shared Interrupt Select
#endif

#if (!defined(_Z8F04A) && !defined(_Z8F04) && !defined(_Z8F08) && !defined(_Z8FMC16)) && !defined(_Z8F1680) || defined(__ZSLBUILD)
#define PS      (*(unsigned char volatile far*)0xFCE)              // Reset = 0x00 Port Select
#define IRQPS   (*(unsigned char volatile far*)0xFCE)              // Reset = 0x00 Port Select
#endif

#define IRQCTL  (*(unsigned char volatile far*)0xFCF)              // Reset = 0x00 Interrupt Control

#define __DATA_DIRECTION          0x01
#define __ALTERNATE_FUNCTION      0x02
#define __ALTERNATE_FUNCTION0     0x02
#define __OUTPUT_CONTROL          0x03
#define __HIGH_DRIVE_ENABLE       0x04
#define __SMR_ENABLE              0x05
#define __PULLUP_ENABLE           0x06
#define __ALTERNATE_FUNCTION1     0x07
#define __ALTERNATE_FUNCTION_SET1 0x07
#define __ALTERNATE_FUNCTION_SET2 0x08
#define __IRQ_EDGE_SELECT         0x08
#define __IRQ_PORT_SELECT         0x09

#define PAADDR  (*(unsigned char volatile far*)0xFD0)              // Reset = 0x00 Port A Address
#define PACTL   (*(unsigned char volatile far*)0xFD1)              // Reset = 0x00 Port A Control
#define PAIN    (*(unsigned char volatile far*)0xFD2)              // Reset = 0xXX Port A Input Data
#define PAOUT   (*(unsigned char volatile far*)0xFD3)              // Reset = 0x00 Pot A Output Data

#define PADD	(((PAADDR) =          __DATA_DIRECTION),((PACTL)))
#if defined(_Z8FMC16)
#define PAAF0	(((PAADDR) =     __ALTERNATE_FUNCTION0),((PACTL)))
#else
#define PAAF	(((PAADDR) =      __ALTERNATE_FUNCTION),((PACTL)))
#endif
#define PAOC	(((PAADDR) =          __OUTPUT_CONTROL),((PACTL)))
#define PAHDE	(((PAADDR) =       __HIGH_DRIVE_ENABLE),((PACTL)))
#define PASMRE	(((PAADDR) =              __SMR_ENABLE),((PACTL)))

#if defined(_Z8F08) || defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680) || defined (__ZSLBUILD)
#define PAPUE	(((PAADDR) =           __PULLUP_ENABLE),((PACTL)))
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define PAAFS1	(((PAADDR) = __ALTERNATE_FUNCTION_SET1),((PACTL)))
#define PAAFS2	(((PAADDR) = __ALTERNATE_FUNCTION_SET2),((PACTL)))
#endif

#if defined(_Z8FMC16)
#define PAAF1     (((PAADDR) =   __ALTERNATE_FUNCTION1),((PACTL)))
#define PAIRQES   (((PAADDR) =       __IRQ_EDGE_SELECT),((PACTL)))
#define PAIRQPSEL (((PAADDR) =       __IRQ_PORT_SELECT),((PACTL)))
#endif

#ifndef EZ8_PORT1
#define PBADDR  (*(unsigned char volatile far*)0xFD4)              // Reset = 0x00 Port B Address
#define PBCTL   (*(unsigned char volatile far*)0xFD5)              // Reset = 0x00 Port B Control
#define PBIN    (*(unsigned char volatile far*)0xFD6)              // Reset = 0xXX Port B Input Data
#define PBOUT   (*(unsigned char volatile far*)0xFD7)              // Reset = 0x00 Port B Output Data

#define PBDD	(((PBADDR) =          __DATA_DIRECTION),((PBCTL)))
#if defined(_Z8FMC16)
#define PBAF0	(((PBADDR) =     __ALTERNATE_FUNCTION0),((PBCTL)))
#else
#define PBAF	(((PBADDR) =      __ALTERNATE_FUNCTION),((PBCTL)))
#endif
#define PBOC	(((PBADDR) =          __OUTPUT_CONTROL),((PBCTL)))
#define PBHDE	(((PBADDR) =       __HIGH_DRIVE_ENABLE),((PBCTL)))
#define PBSMRE	(((PBADDR) =              __SMR_ENABLE),((PBCTL)))

#if  defined(_Z8F08) || defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define PBPUE	(((PBADDR) =           __PULLUP_ENABLE),((PBCTL)))
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define PBAFS1	(((PBADDR) = __ALTERNATE_FUNCTION_SET1),((PBCTL)))
#define PBAFS2	(((PBADDR) = __ALTERNATE_FUNCTION_SET2),((PBCTL)))
#endif

#if defined(_Z8FMC16)
#define PBAF1	(((PBADDR) =     __ALTERNATE_FUNCTION1),((PBCTL)))
#endif

#define PCADDR  (*(unsigned char volatile far*)0xFD8)              // Reset = 0x00 Port C Address
#define PCCTL   (*(unsigned char volatile far*)0xFD9)              // Reset = 0x00 Port C Control
#define PCIN    (*(unsigned char volatile far*)0xFDA)              // Reset = 0xXX Port C Input Data
#define PCOUT   (*(unsigned char volatile far*)0xFDB)              // Reset = 0x00 Port C Output Data

#define PCDD	(((PCADDR) =          __DATA_DIRECTION),((PCCTL)))
#if !defined(_Z8FMC16)
#define PCAF	(((PCADDR) =      __ALTERNATE_FUNCTION),((PCCTL)))
#endif
#define PCOC	(((PCADDR) =          __OUTPUT_CONTROL),((PCCTL)))
#define PCHDE	(((PCADDR) =       __HIGH_DRIVE_ENABLE),((PCCTL)))
#define PCSMRE	(((PCADDR) =              __SMR_ENABLE),((PCCTL)))

#if defined(_Z8F08) || defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define PCPUE	(((PCADDR) =           __PULLUP_ENABLE),((PCCTL)))
#endif

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8F1680) || defined(__ZSLBUILD)
#define PCAFS1	(((PCADDR) = __ALTERNATE_FUNCTION_SET1),((PCCTL)))
#define PCAFS2	(((PCADDR) = __ALTERNATE_FUNCTION_SET2),((PCCTL)))
#endif

#if defined(_Z8FMC16)
#define PCIRQES   (((PCADDR) =       __IRQ_EDGE_SELECT),((PCCTL)))
#endif

#if (defined(EZ8_PORT4) && !defined(_Z8F04)) ||defined(EZ8_PORT8) || defined(EZ8_PORT5) || defined(__ZSLBUILD)
#define PDADDR  (*(unsigned char volatile far*)0xFDC)              // Reset = 0x00 Port D Address
#define PDCTL   (*(unsigned char volatile far*)0xFDD)              // Reset = 0x00 Port D Control
#if !defined(_Z8F04A) || defined(__ZSLBUILD)
#define PDIN    (*(unsigned char volatile far*)0xFDE)              // Reset = 0xXX Port D Input Data
#endif
#define PDOUT   (*(unsigned char volatile far*)0xFDF)              // Reset = 0x00 Port D Output Data

#define PDDD	(((PDADDR) =          __DATA_DIRECTION),((PDCTL)))
#define PDAF	(((PDADDR) =      __ALTERNATE_FUNCTION),((PDCTL)))
#define PDOC	(((PDADDR) =          __OUTPUT_CONTROL),((PDCTL)))
#define PDHDE	(((PDADDR) =       __HIGH_DRIVE_ENABLE),((PDCTL)))
#define PDSMRE	(((PDADDR) =              __SMR_ENABLE),((PDCTL)))

#if defined(_Z8F04A) || defined(__ZSLBUILD)
#define PDPUE	(((PDADDR) =           __PULLUP_ENABLE),((PDCTL)))
#define PDAFS1	(((PDADDR) = __ALTERNATE_FUNCTION_SET1),((PDCTL)))
#define PDAFS2	(((PDADDR) = __ALTERNATE_FUNCTION_SET2),((PDCTL)))
#endif
#if defined(_Z8F1680)
#define PDPUE	(((PDADDR) =           __PULLUP_ENABLE),((PDCTL)))
#endif
#endif
#endif

#if defined(EZ8_PORT8) || defined(EZ8_PORT5) || defined(__ZSLBUILD)
#define PEADDR  (*(unsigned char volatile far*)0xFE0)              // Reset = 0x00 Port E Address
#define PECTL   (*(unsigned char volatile far*)0xFE1)              // Reset = 0x00 Port E Control
#define PEIN    (*(unsigned char volatile far*)0xFE2)              // Reset = 0xXX Port E Input Data
#define PEOUT   (*(unsigned char volatile far*)0xFE3)              // Reset = 0x00 Port E Output Data

#define PEDD	(((PEADDR) =     __DATA_DIRECTION),((PECTL)))
#define PEAF	(((PEADDR) = __ALTERNATE_FUNCTION),((PECTL)))
#define PEOC	(((PEADDR) =     __OUTPUT_CONTROL),((PECTL)))
#define PEHDE	(((PEADDR) =  __HIGH_DRIVE_ENABLE),((PECTL)))
#define PESMRE	(((PEADDR) =         __SMR_ENABLE),((PECTL)))
#if defined(_Z8F1680)
#define PEPUE	(((PEADDR) =      __PULLUP_ENABLE),((PECTL)))
#endif

#if defined(EZ8_PORT8)
#define PFADDR  (*(unsigned char volatile far*)0xFE4)              // Reset = 0x00 Port F Address
#define PFCTL   (*(unsigned char volatile far*)0xFE5)              // Reset = 0x00 Port F Control
#define PFIN    (*(unsigned char volatile far*)0xFE6)              // Reset = 0xXX Port F Input Data
#define PFOUT   (*(unsigned char volatile far*)0xFE7)              // Reset = 0x00 Port F Output Data

#define PFDD	(((PFADDR) =     __DATA_DIRECTION),((PFCTL)))
#define PFAF	(((PFADDR) = __ALTERNATE_FUNCTION),((PFCTL)))
#define PFOC	(((PFADDR) =     __OUTPUT_CONTROL),((PFCTL)))
#define PFHDE	(((PFADDR) =  __HIGH_DRIVE_ENABLE),((PFCTL)))
#define PFSMRE	(((PFADDR) =         __SMR_ENABLE),((PFCTL)))

#define PGADDR  (*(unsigned char volatile far*)0xFE8)              // Reset = 0x00 Port G Address
#define PGCTL   (*(unsigned char volatile far*)0xFE9)              // Reset = 0x00 Port G Control
#define PGIN    (*(unsigned char volatile far*)0xFEA)              // Reset = 0xXX Port G Input Data
#define PGOUT   (*(unsigned char volatile far*)0xFEB)              // Reset = 0x00 Port G Output Data
 
#define PGDD	(((PGADDR) =     __DATA_DIRECTION),((PGCTL)))
#define PGAF	(((PGADDR) = __ALTERNATE_FUNCTION),((PGCTL)))
#define PGOC	(((PGADDR) =     __OUTPUT_CONTROL),((PGCTL)))
#define PGHDE	(((PGADDR) =  __HIGH_DRIVE_ENABLE),((PGCTL)))
#define PGSMRE	(((PGADDR) =         __SMR_ENABLE),((PGCTL)))

#define PHADDR  (*(unsigned char volatile far*)0xFEC)              // Reset = 0x00 Port H Address
#define PHCTL   (*(unsigned char volatile far*)0xFED)              // Reset = 0x00 Port H Control
#define PHIN    (*(unsigned char volatile far*)0xFEE)              // Reset = 0xXX Port H Input Data
#define PHOUT   (*(unsigned char volatile far*)0xFEF)              // Reset = 0x00 Port H Output Data

#define PHDD	(((PHADDR) =     __DATA_DIRECTION),((PHCTL)))
#define PHAF	(((PHADDR) = __ALTERNATE_FUNCTION),((PHCTL)))
#define PHOC	(((PHADDR) =     __OUTPUT_CONTROL),((PHCTL)))
#define PHHDE	(((PHADDR) =  __HIGH_DRIVE_ENABLE),((PHCTL)))
#define PHSMRE	(((PHADDR) =         __SMR_ENABLE),((PHCTL)))
#endif
#endif /* EZ8_PORT8 */

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680)
#define RSTSTAT (*(unsigned char volatile far*)0xFF0)              // Reset = 0xX0 Watchdog Timer Status
#endif
#if !defined(_Z8FMC16) && !defined(_Z8F1680)
#define WDTCTL  (*(unsigned char volatile far*)0xFF0)              // Reset = 0xX0 Watchdog Timer Control
#define WDTU    (*(unsigned char volatile far*)0xFF1)              // Reset = 0xFF Watchdog Timer Reload Upper
#endif
#define WDTHL   (*(unsigned int volatile far*)0xFF2)               // Reset = 0xFFFF Watchdog Timer Reload
#define WDTH    (*(unsigned char volatile far*)0xFF2)              // Reset = 0xFF Watchdog Timer Reload High
#define WDTL    (*(unsigned char volatile far*)0xFF3)              // Reset = 0xFF Watchdog Timer Reload Low

#if defined(_Z8F04A) || defined(_Z8F04) || defined(_Z8FMC16) || defined(_Z8F1680)
#define TRMADR  (*(unsigned char volatile far*)0xFF6)              // Reset = 0x00 Trim Bit Address Register
#define TRMDR   (*(unsigned char volatile far*)0xFF7)              // Reset = 0x00 Trim Bit Data Register

#if defined(_Z8F04A) || defined(_Z8F1680)
#define TTEMP0  (((TRMADR) = 0x00),((TRMDR)))                      // Reset = 0xXX Trim Temperature 0
#define TTEMP1  (((TRMADR) = 0x01),((TRMDR)))                      // Reset = 0xXX Trim Temperature 1
#endif

#if defined(_Z8FMC16)
#define IPO_TRIM  (((TRMADR) = 0x01),((TRMDR)))                    // Reset = 0xXX Trim Internal Precision Oscillator
#define IPO_TRIM1 (((TRMADR) = 0x02),((TRMDR)))                    // Reset = 0xXX Trim Internal Precision Oscillator
#define ADCCAL    (((TRMADR) = 0x04),((TRMDR)))
#else
#define TIPO      (((TRMADR) = 0x02),((TRMDR)))                    // Reset = 0xXX Trim Internal Precision Oscillator
#endif

#if defined(_Z8F1680)
#define TLVD_VBO  (((TRMADR) = 0x03),((TRMDR)))                    // Reset = 0xXX Trim Low Voltage Detect
#define TCOMP_ADC (((TRMADR) = 0x04),((TRMDR)))                    // Reset = 0xXX Trim Comparator and ADC
#define TVREF     (((TRMADR) = 0x05),((TRMDR)))                    // Reset = 0xXX Trim Voltage Reference
#define TBG       (((TRMADR) = 0x06),((TRMDR)))                    // Reset = 0xXX Trim Band Gap
#define TFILTER0  (((TRMADR) = 0x07),((TRMDR)))                    // Reset = 0xXX Trim Filter 0
#define TFILTER1  (((TRMADR) = 0x08),((TRMDR)))                    // Reset = 0xXX Trim Filter 1
#endif

#if defined(_Z8F04A)
#if !defined(_Z8F0830A)
#define TLVD    (((TRMADR) = 0x03),((TRMDR)))                      // Reset = 0xXX Trim Low Voltage Detect Trim
#endif
#define TBG     (((TRMADR) = 0x04),((TRMDR)))                      // Reset = 0xXX Trim Band Gap Trim
#define TUSER5  (((TRMADR) = 0x05),((TRMDR)))                      // Reset = 0xXX Trim User 5
#define TUSER6  (((TRMADR) = 0x06),((TRMDR)))                      // Reset = 0xXX Trim User 6
#define TUSER7  (((TRMADR) = 0x07),((TRMDR)))                      // Reset = 0xXX Trim User 7
#define TUSER8  (((TRMADR) = 0x08),((TRMDR)))                      // Reset = 0xXX Trim User 8
#define TUSER9  (((TRMADR) = 0x09),((TRMDR)))                      // Reset = 0xXX Trim User 9
#define TUSER10 (((TRMADR) = 0x0A),((TRMDR)))                      // Reset = 0xXX Trim User 10
#define TUSER11 (((TRMADR) = 0x0B),((TRMDR)))                      // Reset = 0xXX Trim User 11
#define TUSER12 (((TRMADR) = 0x0C),((TRMDR)))                      // Reset = 0xXX Trim User 12
#define TUSER13 (((TRMADR) = 0x0D),((TRMDR)))                      // Reset = 0xXX Trim User 13
#define TUSER14 (((TRMADR) = 0x0E),((TRMDR)))                      // Reset = 0xXX Trim User 14
#define TUSER15 (((TRMADR) = 0x0F),((TRMDR)))                      // Reset = 0xXX Trim User 15
#define TUSER16 (((TRMADR) = 0x10),((TRMDR)))                      // Reset = 0xXX Trim User 16
#define TUSER17 (((TRMADR) = 0x11),((TRMDR)))                      // Reset = 0xXX Trim User 17
#define TUSER18 (((TRMADR) = 0x12),((TRMDR)))                      // Reset = 0xXX Trim User 18
#define TUSER19 (((TRMADR) = 0x13),((TRMDR)))                      // Reset = 0xXX Trim User 19
#define TUSER20 (((TRMADR) = 0x14),((TRMDR)))                      // Reset = 0xXX Trim User 20
#define TUSER21 (((TRMADR) = 0x15),((TRMDR)))                      // Reset = 0xXX Trim User 21
#define TUSER22 (((TRMADR) = 0x16),((TRMDR)))                      // Reset = 0xXX Trim User 22
#define TUSER23 (((TRMADR) = 0x17),((TRMDR)))                      // Reset = 0xXX Trim User 23
#define TUSER24 (((TRMADR) = 0x18),((TRMDR)))                      // Reset = 0xXX Trim User 24
#define TUSER25 (((TRMADR) = 0x19),((TRMDR)))                      // Reset = 0xXX Trim User 25
#define TUSER26 (((TRMADR) = 0x1A),((TRMDR)))                      // Reset = 0xXX Trim User 26
#define TUSER27 (((TRMADR) = 0x1B),((TRMDR)))                      // Reset = 0xXX Trim User 27
#define TUSER28 (((TRMADR) = 0x1C),((TRMDR)))                      // Reset = 0xXX Trim User 28
#define TUSER29 (((TRMADR) = 0x1D),((TRMDR)))                      // Reset = 0xXX Trim User 29
#define TUSER30 (((TRMADR) = 0x1E),((TRMDR)))                      // Reset = 0xXX Trim User 30
#define TUSER31 (((TRMADR) = 0x1F),((TRMDR)))                      // Reset = 0xXX Trim User 31
#endif
#endif

#define FCTL    (*(unsigned char volatile far*)0xFF8)              // Reset = 0x00 FLASH Control
#define FSTAT   (*(unsigned char volatile far*)0xFF8)              // Reset = 0x00 FLASH Status
#define FPS     (*(unsigned char volatile far*)0xFF9)              // Reset = 0x00 FLASH Page Select
#if defined(_Z8F642) || defined(_Z8F08)
#define RPS     (*(unsigned char volatile far*)0xFF9)              // Reset = 0x00 ROM Page Select
#endif
#if  defined(_Z8F642) || defined(_Z8F04A) || defined(_Z8F08) || defined(_Z8F04) || defined(_Z8FMC16)|| defined(_Z8F1680)
#define FPROT   (*(unsigned char volatile far*)0xFF9)              // Reset = 0x00 FLASH Sector Protect
#endif
#define FPF     (*(unsigned int volatile far*)0xFFA)               // Reset = 0x0000 FLASH Programming Frequency
#define FPFH    (*(unsigned char volatile far*)0xFFA)              // Reset = 0x00 FLASH Programming Frequency High
#define FFREQ   (*(unsigned int volatile far*)0xFFA)               // Reset = 0x0000 FLASH Programming Frequency
#define FFREQH  (*(unsigned char volatile far*)0xFFA)              // Reset = 0x00 FLASH Programming Frequency High
#define FPFL    (*(unsigned char volatile far*)0xFFB)              // Reset = 0x00 FLASH Programming Frequency Low
#define FFREQL  (*(unsigned char volatile far*)0xFFB)              // Reset = 0x00 FLASH Programming Frequency Low

#define FLAGS   (*(unsigned char volatile far*)0xFFC)              // Reset = 0xXX Flags Register
#define RP      (*(unsigned char volatile far*)0xFFD)              // Reset = 0xXX Register Pointer
#define SPH     (*(unsigned char volatile far*)0xFFE)              // Reset = 0xXX Stack Pointer High
#define SPL     (*(unsigned char volatile far*)0xFFF)              // Reset = 0xXX  Stack Pointer Low

#define FLASH_OPTION1  rom char flash_option1 _At 0x0

#define FLASH_OPTION2  rom char flash_option2 _At 0x1                                        

/*      Macros to enable and disable interrupts */

intrinsic void EI(void);
intrinsic void DI(void);
intrinsic void SET_VECTOR(int vect,void (*hndlr)(void));

// Compatibility

#define _ei EI
#define _di DI
#define _setvector SET_VECTOR
#define FREQ20000	(20000000/1000)
#define FREQ18432	(18432000/1000)
#define FREQ16000	(16000000/1000)
#define FREQ14000	(14000000/1000)
#define FREQ12000	(12000000/1000)
#define FREQ08000	( 8000000/1000)
#define FREQ04000	( 4000000/1000)

void reentrant INIT_FLASH(unsigned short freq);
void reentrant WRITE_FLASH(rom const void *addr,char val);
char reentrant READ_FLASH(rom const void *addr); 

#if defined(EZ8_NVDS)
char reentrant READ_NVDS(char addr);
int reentrant WRITE_NVDS(char value, char addr);

int reentrant READ_NVDS_GET_STATUS(char addr);
char reentrant WRITE_NVDS_GET_STATUS(char value, char addr);

#define nvds_read READ_NVDS
#define nvds_write WRITE_NVDS

#define nvds_read_get_status READ_NVDS_GET_STATUS
#define nvds_write_get_status WRITE_NVDS_GET_STATUS
#endif

#if defined(_ZSL_PORT_USED) || defined(__ZSLBUILD)
#include <gpio.h>
#endif

#if defined(_ZSL_UART_USED) || defined(__ZSLBUILD)
#include <uart.h>
#include <dmadefs.h>
#endif

#endif


