#include <stdio.h>
#include <math.h>

void hypcos(void)
{
    float x, y;
    int j;          // not static
    static int i;   // recall: initialized to zero

    x = exp(++i);
    y = exp(-i);

    printf("hypcos[%2d] = %f\n", i, (x + y)/2);
    j++;
    printf("hypcos j = %d\n", j);
}

void junk(void)
{
    float x, y;
    int i, k[10], j, m;

    i = -999;
    j = 23;
    printf("junk j = %d\n", j);
}

int main(void)
{
    int j;

    for (j=0; j<10; j++) {
        hypcos();
        junk();
    }

    return 0;
}

