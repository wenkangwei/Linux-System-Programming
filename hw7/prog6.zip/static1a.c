//  The hypsin function is in static1b.c  Compile with
//
//  gcc -g -Wall static1a.c static1b.c -o static1.out -lm

#include <stdio.h>
#include <math.h>

// This is bad programming, but illustrates the use of a global variable
// With static visible to file only.  Without visiable to both files
//static int i;
int i;

extern void hypsin(void);

void hypcos(void)
{
    float x, y;

    x = exp(i);
    y = exp(-i);

    printf("hypcos[%2d] = %f", i, (x + y)/2);
}

int main(void)
{

    for (i=-9; i<10; i++) {
        hypcos();
        hypsin();
    }

    return 0;
}


