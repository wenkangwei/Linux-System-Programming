/* Demonstrate opendir(), readdir(), closedir() */
/* This example taken from the UULP textbook */

#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>

int main(int argc, char *argv[])

{
    DIR *dir_ptr;            /* the directory */
    struct dirent *direntp;  /* each entry */

    dir_ptr=opendir(".");
    if (dir_ptr == NULL)
    {
        printf("Unable to opendir %s\n",".");
        exit(1);
    }

    while ((direntp=readdir(dir_ptr)) != NULL)
    {
        printf("%s\n", direntp->d_name);
    }

    closedir(dir_ptr);

    return 0;
}
