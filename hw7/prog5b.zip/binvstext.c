#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *fout_b, *fout_t;
    int i, n;

    fout_b = fopen("BinVsText.bin", "wb");
    fout_t = fopen("BinVsText.txt", "wt");

    /* Write binary numbers to file */
    for (i=0; i<10; i++) {
        n = rand();
        fwrite(&n, 4, 1, fout_b);
        fwrite("\n", 1, 1, fout_b);
        fwrite(&n, 4, 1, fout_t);
        fwrite("\n", 1, 1, fout_t);
    }

    /* Use text functions to write to files */
    for (i=0; i<10; i++) {
        n = rand();
        fprintf(fout_b, "%d", n);
        fprintf(fout_b, "\n");
        fprintf(fout_t, "%d", n);
        fprintf(fout_t, "\n");
    }

    fclose(fout_b);
    fclose(fout_t);

    return 0;
}


