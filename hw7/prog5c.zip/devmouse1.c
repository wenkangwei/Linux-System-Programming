/* Demonstrate reading bytes from mouse, opening device file */

#include <stdlib.h>
#include <stdio.h>

int main(void)
{
    FILE *fpt;
    int c;
    int buf[30];

    fpt = fopen("/dev/psaux","r");
    if (fpt == NULL) {
        printf("Cannot open input file \"%s\"\n", "/dev/psaux");
        exit(0);
    }
    while (1) {
        c = fread(buf,4,1,fpt);
        printf("Read %d bytes:  %d\n",c,buf[0]);
    }
    fclose(fpt);
    exit(0);
}



